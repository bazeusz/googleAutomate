import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class SearchForArsenalInGoogle {
    private static final WebDriver driver = new ChromeDriver();

    @BeforeSuite
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", Utils.CHROME_DRIVER_LOCATION);
    }

    @Test(testName = "Search for Arsenal in Google")
    public static void searchArsenal(){
        driver.get(Utils.BASE_URL);
        WebForm webForm = new WebForm(driver);
        webForm.cookieesAgree();
        webForm.typeValueInSearchInputAndSearch(webForm.GOOGLE_SEARCH_ARSENAL);
        webForm.clickOnSearchButton();
        webForm.verifyStatsDisplayedOnResultScreen();
    }

    @AfterSuite
    public static void clean(){
        driver.manage().deleteAllCookies();
        driver.close();
    }
}
