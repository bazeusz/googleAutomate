import net.bytebuddy.asm.Advice;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

import java.util.List;


public class WebForm extends PageObject{

    //constants
    public final String GOOGLE_SEARCH_ARSENAL = "Arsenal London";
    public final String GOOGLE_SEARCH_SPECIAL_SIGNS = "+++++";

    private final String SEARCH_BOX_TITLE = "Search";
    public final String SEARCH_BUTTON_NAME = "btnK";
    private final String SEARCH_BOX_NAME = "q";
    private final String COOKIEE_AGREE_ID = "L2AGLb";
    public final String RESULT_STATS_ID = "result-stats";
    private final String EMPTY_RESULT_ID = "topstuff";
    private final String EXPECTED_EMPTY_RESULT_STRING = "Your search - +++++ - did not match any documents.";
    private final String BOTTOM_LEFT_DIV_CLASS = "pHiOh";
    private final String ABOUT_LINK = "About";
    private final String ADVERTISING_LINK = "Advertising";
    private final String BUSINESS_LINK = "Business";
    private final String HOW_SEARCH_WORKS_LINK = "How Search works";
    private final String PRIVACY_LINK = "Privacy";
    private final String TERMS_LINK = "Terms";

    //steps definitions
    public void typeValueInSearchInputAndSearch(String input){
        driver.findElement(By.name(SEARCH_BOX_NAME)).sendKeys(input);
    }

    //validations
    @FindBy(id = RESULT_STATS_ID)
    private WebElement alertSuccess;

    public void cookieesAgree(){
        ((ChromeDriver) driver).findElementById(COOKIEE_AGREE_ID).click();
    }

    public void verifyStatsDisplayedOnResultScreen(){
        this.alertSuccess.isDisplayed();
    }

    public void clickOnSearchButton(){
        List<WebElement> elements = ((ChromeDriver) driver).findElementsByName(SEARCH_BUTTON_NAME);
        elements.get(1).click();
    }

    public void verifyEmptyResultInfo(){
        final String resultText = ((ChromeDriver) driver).findElementById(EMPTY_RESULT_ID).getText();
        if (!resultText.contains(EXPECTED_EMPTY_RESULT_STRING)){
            throw new ElementNotVisibleException("Wrong result message. Expected: " + EXPECTED_EMPTY_RESULT_STRING);
        }
    }

    public void verifyFooterLinks(){
        List<WebElement> list = ((ChromeDriver) driver).findElementsByClassName("pHiOh");
        String[] links = {ABOUT_LINK, ADVERTISING_LINK, BUSINESS_LINK, HOW_SEARCH_WORKS_LINK, PRIVACY_LINK, TERMS_LINK};
        for (int i = 0; i < 5; i++){
            String resultText = list.get(i).getText();
            if (!resultText.equals(links[i])){
                throw new ElementNotVisibleException("Cannot find the link: " + links[i]);
            }
        }
    }

    public WebForm(WebDriver driver) {
        super(driver);
    }

}
