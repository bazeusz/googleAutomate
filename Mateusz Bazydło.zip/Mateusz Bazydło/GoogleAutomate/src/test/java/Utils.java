public class Utils {
    final static String BASE_URL = "https://www.google.com";
    final static String CHROME_DRIVER_LOCATION = "chromedriver";
}
